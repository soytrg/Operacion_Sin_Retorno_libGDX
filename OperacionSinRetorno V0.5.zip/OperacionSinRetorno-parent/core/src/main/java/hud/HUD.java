package hud;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

public class HUD {  // <- AGREGUÉ "public" AQUÍ
    private Stage stage;
    private Viewport viewport;
    private Integer vidas;
    private Integer puntuacion;
    private Label vidasLabel;
    private Label puntuacionLabel;
    private Label tiempoLabel;
    private Label municionLabel;
    private Label powerUpLabel;

    public HUD(SpriteBatch batch) {
        vidas = 3;
        puntuacion = 0;

        // Cámara y viewport independientes del juego
        viewport = new FitViewport(800, 600, new OrthographicCamera());
        stage = new Stage(viewport, batch);

        // Fuente simple para los labels
        BitmapFont font = new BitmapFont();

        // Estilos para Labels
        Label.LabelStyle estiloNormal = new Label.LabelStyle(font, Color.WHITE);
        Label.LabelStyle estiloPowerUp = new Label.LabelStyle(font, Color.YELLOW);

        // Inicializamos los Labels
        vidasLabel = new Label("Vidas: " + vidas, estiloNormal);
        puntuacionLabel = new Label("Puntos: " + puntuacion, estiloNormal);
        tiempoLabel = new Label("Tiempo: 00", estiloNormal);
        municionLabel = new Label("Munición: 30/30", estiloNormal);
        powerUpLabel = new Label("", estiloPowerUp);

        // Creamos una tabla para ordenar los elementos
        Table tabla = new Table();
        tabla.top().left();
        tabla.setFillParent(true);

        // Añadimos a la tabla
        tabla.add(vidasLabel).padTop(10).padLeft(10);
        tabla.row();
        tabla.add(municionLabel).padTop(5).padLeft(10);
        tabla.row();
        tabla.add(puntuacionLabel).padTop(5).padLeft(10);
        tabla.row();
        tabla.add(tiempoLabel).padTop(5).padLeft(10);
        tabla.row();
        tabla.add(powerUpLabel).padTop(5).padLeft(10);

        // Añadimos la tabla al Stage
        stage.addActor(tabla);
    }

    public void render() {
        stage.draw();
    }

    public void resize(int width, int height) {
        viewport.update(width, height);
    }

    public void dispose() {
        stage.dispose();
    }

    public void sumarPuntos(int puntos) {
        puntuacion += puntos;
        puntuacionLabel.setText("Puntos: " + puntuacion);
    }

    public void perderVida() {
        if (vidas > 0) vidas--;
        vidasLabel.setText("Vidas: " + vidas);
    }

    public void actualizarTiempo(int segundos) {
        tiempoLabel.setText("Tiempo: " + segundos);
    }

    // === NUEVOS MÉTODOS PARA MUNICIÓN Y POWER-UP ===
    public void actualizarMunicion(int actual, int maxima, boolean recargando, float progreso) {
        String texto = "Munición: " + actual + "/" + maxima;
        if (recargando) {
            int porcentaje = (int)(progreso * 100);
            texto += " (Recargando " + porcentaje + "%)";
        }
        municionLabel.setText(texto);
    }

    public void actualizarPowerUp(boolean activo, float tiempoRestante) {
        if (activo) {
            int segundos = (int)Math.ceil(tiempoRestante);
            powerUpLabel.setText("RECARGA RÁPIDA: " + segundos + "s");
            powerUpLabel.setColor(Color.YELLOW);
        } else {
            powerUpLabel.setText("");
        }
    }

    public Stage getStage() {
        return stage;
    }
}