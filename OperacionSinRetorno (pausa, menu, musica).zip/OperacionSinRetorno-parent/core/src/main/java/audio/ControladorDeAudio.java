package audio;
import java.util.HashMap;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;

public class ControladorDeAudio {
    // Musica:
    private Music musicaNivel1;
    private Music musicaMenu;
    private float volumenMusica = 0.5f, volumenEfectosDeSonido = 1.0f;
    private final float MAX = 1f, MIN = 0;
    private boolean musicaMenuReproduciendo = false;
    
    // Sonidos:
    private HashMap<String, Sound> efectosDeSonido = new HashMap<>();
    
    public void cargarMusica() {
        this.musicaMenu = Gdx.audio.newMusic(Gdx.files.internal("Efectos de sonido/menu_select.mp3"));
        this.musicaMenu.setLooping(true);
        this.musicaMenu.setVolume(this.volumenMusica);
        
        // Cargar música del nivel 1
        this.musicaNivel1 = Gdx.audio.newMusic(Gdx.files.internal("Musica/Musica nivel 1.mp3"));
        this.musicaNivel1.setLooping(true);
        this.musicaNivel1.setVolume(this.volumenMusica);
    }
    
    public void cargarSonidos(String nombre, String rutaSonido) {
        this.efectosDeSonido.put(nombre, Gdx.audio.newSound(Gdx.files.internal(rutaSonido)));
    }
    
    public void reproducirSonido(String nombre) {
        Sound s = efectosDeSonido.get(nombre);
        if (s != null) s.play(volumenEfectosDeSonido);
    }
    
    // === MÉTODOS PARA MÚSICA DEL MENÚ ===
    public void iniciarMusicaMenu() {
        if (!musicaMenuReproduciendo && !this.musicaMenu.isPlaying()) {
            this.musicaMenu.play();
            musicaMenuReproduciendo = true;
            
            System.out.println("Estoy reproduciendo musica"); 
           
            
            
           
            
           
        }
    }
    
    public void detenerMusicaMenu() {
        if (musicaMenuReproduciendo) {
            this.musicaMenu.stop();
            musicaMenuReproduciendo = false;
        }
    }
    
    public void pausarMusicaMenu() {
        this.musicaMenu.pause();
    }
    
    // === MÉTODOS PARA MÚSICA DEL NIVEL 1 ===
    public void iniciarMusicaNivel1() {
        detenerMusicaMenu(); // Detener música del menú primero
        if (!this.musicaNivel1.isPlaying()) {
            this.musicaNivel1.play();
        }
    }
    
    public void reproducirMusica() {
        if (!this.musicaNivel1.isPlaying()) {
            this.musicaNivel1.play();
        }
    }
    
    public void pausarMusica() {
        this.musicaNivel1.pause();
    }
    
    public void pararMusica() {
        this.musicaNivel1.stop();
    }
    
    public void detenerMusicaNivel1() {
        this.musicaNivel1.stop();
    }
    
    // === MÉTODOS PARA VOLVER AL MENÚ ===
    public void volverAlMenu() {
        detenerMusicaNivel1();
        iniciarMusicaMenu();  // Asegura que se reproduce la música del menú
    }

    
    // === CONTROL DE VOLUMEN SONIDOS ===
    public void subirVolumenSonidos() {
        if(this.volumenEfectosDeSonido < this.MAX) {
            this.volumenEfectosDeSonido += 0.1f;
        } 
        else {
            this.volumenEfectosDeSonido = 1.0f;
        }
    }
    
    public void bajarVolumenSonidos() {
        if(this.volumenEfectosDeSonido > this.MIN) {
            // ¿Porque esto no es igual a "subirVolumen"?
            // Debido a una complicacion, en la que cuando llega a 0 se imprime lo siguiente:"1.4901161E-8"
            // Luego de bajar el volumen devuelta el juego crashea, esta linea hace que "volumen" se quede en 0. 
            // y evita crashear el programa.
            this.volumenEfectosDeSonido = Math.max(0f, this.volumenEfectosDeSonido - 0.1f);
        } 
        else {
            this.volumenEfectosDeSonido= 0f;
        }
    }
    
    // === CONTROL DE VOLUMEN MÚSICA ===
    public void subirVolumenMusica() {
        if(this.volumenMusica < this.MAX) {
            this.volumenMusica += 0.1f;
            this.musicaNivel1.setVolume(this.volumenMusica);
            this.musicaMenu.setVolume(this.volumenMusica);
        } 
        else {
            this.volumenMusica = 1.0f;
            this.musicaNivel1.setVolume(1f);
            this.musicaMenu.setVolume(1f);
        }
    }
    
    public void bajarVolumenMusica() {
        if(this.volumenMusica > this.MIN) {
            // ¿Porque esto no es igual a "subirVolumen"?
            // Debido a una complicacion, en la que cuando llega a 0 se imprime lo siguiente:"1.4901161E-8"
            // Luego de bajar el volumen devuelta el juego crashea, esta linea hace que "volumen" se quede en 0. 
            // y evita crashear el programa.
            this.volumenMusica = Math.max(0f, this.volumenMusica - 0.1f);
            this.musicaNivel1.setVolume(this.volumenMusica);
            this.musicaMenu.setVolume(this.volumenMusica);
        } 
        else {
            this.volumenMusica = 0f;
            this.musicaNivel1.setVolume(0);
            this.musicaMenu.setVolume(0);
        }
    }
    
    public void dispose() {
        this.musicaNivel1.dispose();
        this.musicaMenu.dispose();
        for (Sound s : efectosDeSonido.values()) {
            s.dispose();
        }
    }
}