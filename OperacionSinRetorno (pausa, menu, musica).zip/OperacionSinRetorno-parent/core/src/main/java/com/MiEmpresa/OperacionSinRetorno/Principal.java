package com.MiEmpresa.OperacionSinRetorno;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapRenderer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.utils.ScreenUtils;

import audio.ControladorDeAudio;
import jugador.ControladorEntrada;
import jugador.Jugador;

public class Principal extends ApplicationAdapter {
    private SpriteBatch batch;
    private Texture image;
    private BitmapFont font;

    private EstadoJuego estadoActual = EstadoJuego.MENU_PRINCIPAL;
    private ConfiguracionJuego config;

    private MenuPrincipal menuPrincipal;
    private MenuPersonalizacion menuPersonalizacion;
    private MenuDificultad menuDificultad;
    private MenuOpciones menuOpciones;

    private TiledMap tiledMap;
    private OrthographicCamera camara;
    public TiledMapRenderer tiledMapRenderer;

    private ControladorDeAudio controladorDeAudio;

    private Jugador jugador;
    private ControladorEntrada controladorDeEntrada;
    private ShapeRenderer shapeRenderer;

    private boolean juegoInicializado = false;

    @Override
    public void create() {
        batch = new SpriteBatch();
        image = new Texture("libgdx.png");
        font = new BitmapFont();
        font.getData().setScale(2.0f);

        config = ConfiguracionJuego.getInstancia();

        float w = Gdx.graphics.getWidth();
        float h = Gdx.graphics.getHeight();
        camara = new OrthographicCamera();
        camara.setToOrtho(false, w, h);
        camara.update();

        controladorDeAudio = new ControladorDeAudio();
        controladorDeAudio.cargarMusica();
        controladorDeAudio.iniciarMusicaMenu();
        controladorDeAudio.cargarSonidos("salto", "Efectos de sonido/Sonido de salto.mp3");
        controladorDeAudio.cargarSonidos("menu_select", "Efectos de sonido/menu_select.mp3");
        controladorDeAudio.cargarSonidos("menu_move", "Efectos de sonido/menu_move.mp3");

        menuPrincipal = new MenuPrincipal(this, font, controladorDeAudio);
        menuPersonalizacion = new MenuPersonalizacion(this, font, controladorDeAudio);
        menuDificultad = new MenuDificultad(this, font, controladorDeAudio);
        menuOpciones = new MenuOpciones(this, font, controladorDeAudio);

        controladorDeEntrada = new ControladorEntrada();
        shapeRenderer = new ShapeRenderer();

        Gdx.input.setInputProcessor(menuPrincipal);
    }

    @Override
    public void render() {
        ScreenUtils.clear(0.15f, 0.15f, 0.2f, 1f);
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        switch (estadoActual) {
            case MENU_PRINCIPAL:
                menuPrincipal.render(batch);
                break;

            case MENU_PERSONALIZACION:
                menuPersonalizacion.render(batch);
                break;

            case MENU_DIFICULTAD:
                menuDificultad.render(batch);
                break;

            case OPCIONES:
                menuOpciones.render(batch);
                break;

            case JUGANDO_SOLO:
            case JUGANDO_COOPERATIVO:
                if (!juegoInicializado) {
                    inicializarJuego();
                    juegoInicializado = true;
                }
                renderJuego();
                break;

            case PAUSADO:
                renderJuego();  // Solo dibuja, no actualiza
                renderMenuPausa();
                break;

            case GAME_OVER:
                renderGameOver();
                break;
        }
    }

    private void inicializarJuego() {
        tiledMap = new TmxMapLoader().load("Mapas_Niveles/Nivel 1.tmx");
        tiledMapRenderer = new OrthogonalTiledMapRenderer(tiledMap);

        jugador = new Jugador();

        Gdx.input.setInputProcessor(controladorDeEntrada);

        controladorDeAudio.iniciarMusicaNivel1();
    }

    private void renderJuego() {
        // Siempre se dibuja el mapa y jugador
        camara.update();
        tiledMapRenderer.setView(camara);
        tiledMapRenderer.render();

        batch.begin();
        jugador.render(batch);
        batch.end();

        shapeRenderer.begin(ShapeRenderer.ShapeType.Line);
        shapeRenderer.setColor(Color.RED);
        shapeRenderer.rect(jugador.getX(), jugador.getY(), 32, 32);
        shapeRenderer.end();

        // Si está pausado, no actualizamos lógica ni entrada
        if (estadoActual == EstadoJuego.PAUSADO) {
            return;
        }

        // Lógica del juego
        float dx = 0;
        boolean saltar = false;
        boolean disparoIzquierdaArriba = false;
        boolean disparoDerechaArriba = false;
        boolean agacharse = false;

        boolean izquierda = Gdx.input.isKeyPressed(Input.Keys.A);
        boolean derecha = Gdx.input.isKeyPressed(Input.Keys.D);
        boolean arriba = Gdx.input.isKeyPressed(Input.Keys.W);
        boolean abajo = Gdx.input.isKeyPressed(Input.Keys.S);

        if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
            estadoActual = EstadoJuego.PAUSADO;
            return;
        }

        if (abajo) {
            agacharse = true;
        }

        if (!agacharse && izquierda && arriba) {
            disparoIzquierdaArriba = true;
            dx = -1;
        } else if (!agacharse && derecha && arriba) {
            disparoDerechaArriba = true;
            dx = 1;
        } else if (!agacharse) {
            if (izquierda) {
                dx = -1;
            } else if (derecha) {
                dx = 1;
            }
            if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
                controladorDeAudio.reproducirSonido("salto");
                saltar = true;
            }
        }

        jugador.actualizar(dx, saltar, disparoIzquierdaArriba, disparoDerechaArriba, agacharse, Gdx.graphics.getDeltaTime());
    }

    private void renderMenuPausa() {
        batch.begin();
        font.setColor(Color.WHITE);
        font.draw(batch, "JUEGO PAUSADO", Gdx.graphics.getWidth() / 2 - 100, Gdx.graphics.getHeight() / 2 + 50);
        font.draw(batch, "Presiona ENTER para continuar", Gdx.graphics.getWidth() / 2 - 150, Gdx.graphics.getHeight() / 2);
        font.draw(batch, "Presiona M para volver al menu", Gdx.graphics.getWidth() / 2 - 150, Gdx.graphics.getHeight() / 2 - 50);
        batch.end();

        if (Gdx.input.isKeyJustPressed(Input.Keys.ENTER)) {
            if (config.isModoCooperativo()) {
                estadoActual = EstadoJuego.JUGANDO_COOPERATIVO;
            } else {
                estadoActual = EstadoJuego.JUGANDO_SOLO;
            }
        }

        if (Gdx.input.isKeyJustPressed(Input.Keys.M)) {
            volverAlMenuPrincipal();
        }
    }

    private void renderGameOver() {
        batch.begin();
        font.setColor(Color.RED);
        font.draw(batch, "GAME OVER", Gdx.graphics.getWidth() / 2 - 80, Gdx.graphics.getHeight() / 2 + 50);
        font.setColor(Color.WHITE);
        font.draw(batch, "Presiona R para reiniciar", Gdx.graphics.getWidth() / 2 - 120, Gdx.graphics.getHeight() / 2);
        font.draw(batch, "Presiona M para volver al menu", Gdx.graphics.getWidth() / 2 - 150, Gdx.graphics.getHeight() / 2 - 50);
        batch.end();

        if (Gdx.input.isKeyJustPressed(Input.Keys.R)) {
            juegoInicializado = false;
            if (config.isModoCooperativo()) {
                estadoActual = EstadoJuego.JUGANDO_COOPERATIVO;
            } else {
                estadoActual = EstadoJuego.JUGANDO_SOLO;
            }
        }

        if (Gdx.input.isKeyJustPressed(Input.Keys.M)) {
            volverAlMenuPrincipal();
        }
    }

    public void cambiarEstado(EstadoJuego nuevoEstado) {
        estadoActual = nuevoEstado;

        switch (nuevoEstado) {
            case MENU_PRINCIPAL:
                Gdx.input.setInputProcessor(menuPrincipal);
                break;
            case MENU_PERSONALIZACION:
                Gdx.input.setInputProcessor(menuPersonalizacion);
                break;
            case MENU_DIFICULTAD:
                Gdx.input.setInputProcessor(menuDificultad);
                break;
            case OPCIONES:
                Gdx.input.setInputProcessor(menuOpciones);
                break;
            case JUGANDO_SOLO:
            case JUGANDO_COOPERATIVO:
                Gdx.input.setInputProcessor(controladorDeEntrada);
                break;
        }
    }

    public void volverAlMenuPrincipal() {
        juegoInicializado = false;
        estadoActual = EstadoJuego.MENU_PRINCIPAL;
        Gdx.input.setInputProcessor(menuPrincipal);
        controladorDeAudio.volverAlMenu();
    }

    public void iniciarJuego() {
        if (config.isModoCooperativo()) {
            estadoActual = EstadoJuego.JUGANDO_COOPERATIVO;
        } else {
            estadoActual = EstadoJuego.JUGANDO_SOLO;
        }
        juegoInicializado = false;
        Gdx.input.setInputProcessor(controladorDeEntrada);
    }

    @Override
    public void dispose() {
        batch.dispose();
        image.dispose();
        font.dispose();
        if (controladorDeAudio != null) {
            controladorDeAudio.dispose();
        }
        if (jugador != null) {
            jugador.dispose();
        }
        if (shapeRenderer != null) {
            shapeRenderer.dispose();
        }
        if (tiledMap != null) {
            tiledMap.dispose();
        }
    }
}
