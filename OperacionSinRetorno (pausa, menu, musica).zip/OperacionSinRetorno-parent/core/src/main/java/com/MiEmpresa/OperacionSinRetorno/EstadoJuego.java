package com.MiEmpresa.OperacionSinRetorno;

public enum EstadoJuego {
    MENU_PRINCIPAL,
    MENU_PERSONALIZACION,
    MENU_DIFICULTAD,
    OPCIONES,
    JUGANDO_SOLO,
    JUGANDO_COOPERATIVO,
    PAUSADO,
    GAME_OVER
}