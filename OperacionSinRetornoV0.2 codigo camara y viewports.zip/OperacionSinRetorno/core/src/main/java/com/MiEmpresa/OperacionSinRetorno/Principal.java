package com.MiEmpresa.OperacionSinRetorno;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.maps.MapLayer;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.MapObjects;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapRenderer;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FillViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import audio.ControladorDeAudio;
import jugador.ControladorEntrada;
import jugador.Jugador;

/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. */
public class Principal extends ApplicationAdapter  {
    private SpriteBatch batch;
    private Texture image;
    
    //Camara:
    private OrthographicCamera camara;
    private Viewport viewport;
    
    private static final float ANCHO_PANTALLA = 800;
    private static final float ALTO_PANTALLA = 600;
    
    //Mapa:
    private TiledMap tiledMap;
    public TiledMapRenderer tiledMapRenderer;
    private TiledMapTileLayer capaColisiones;
    
    //Audio:
    private ControladorDeAudio controladorDeAudio;

    //Jugador:
    private Jugador jugador;
    private ControladorEntrada controladorDeEntrada;
    private ShapeRenderer shapeRenderer;
    
    
    public void create() {
        batch = new SpriteBatch();
        image = new Texture("libgdx.png");
        
        //Camara:
//        float anchoPantalla = Gdx.graphics.getWidth();
//        float altoPantalla = Gdx.graphics.getHeight(); 
        camara = new OrthographicCamera();
//        camara.setToOrtho(false,anchoPantalla,altoPantalla);
        viewport = new FillViewport(ANCHO_PANTALLA, ALTO_PANTALLA, camara);
        camara.update();
        
        //Mapa:
        tiledMap = new TmxMapLoader().load("Mapas_Niveles/Nivel 1.tmx");
        tiledMapRenderer = new OrthogonalTiledMapRenderer(tiledMap);
        capaColisiones = (TiledMapTileLayer) tiledMap.getLayers().get("colisiones");
        
        //Audio:
        
        //Musica:
        controladorDeAudio = new ControladorDeAudio();
        controladorDeAudio.cargarMusica();
        controladorDeAudio.reproducirMusica();
        
        //Efectos de sonido:
        // El identificador de los sonidos tiene que ser TODO MINUSCULA.("identificador", "ruta del sonido");
        controladorDeAudio.cargarSonidos("salto", "Efectos de sonido/Sonido de salto.mp3");
        
        //Jugador: 
        controladorDeEntrada = new ControladorEntrada();
        shapeRenderer = new ShapeRenderer();

        MapObject spawnObj = tiledMap.getLayers().get("spawns").getObjects().get("spawn");
        float spawnX = (float) spawnObj.getProperties().get("x");
        float spawnY = (float) spawnObj.getProperties().get("y");

        // Crear jugador en esa posición
        jugador = new Jugador(spawnX, spawnY);
        
        Gdx.input.setInputProcessor(controladorDeEntrada);
    }

    public void render() {
    	float dx = 0;
        boolean saltar = false;
        boolean disparoIzquierdaArriba = false;
        boolean disparoDerechaArriba = false;
        boolean agacharse = false;

        // Detectar movimiento horizontal
        boolean izquierda = Gdx.input.isKeyPressed(Input.Keys.A);
        boolean derecha = Gdx.input.isKeyPressed(Input.Keys.D);
        boolean arriba = Gdx.input.isKeyPressed(Input.Keys.W);
        boolean abajo = Gdx.input.isKeyPressed(Input.Keys.S);

        ScreenUtils.clear(0.15f, 0.15f, 0.2f, 1f);
        Gdx.gl.glClearColor(0, 0, 0, 0);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        
        viewport.apply();
        
        // Detectar agacharse
        if (abajo) {
            agacharse = true;
        }

        // Detectar combinaciones para disparos diagonales (solo si no se está agachando)
        if (!agacharse && izquierda && arriba) 
        {
            disparoIzquierdaArriba = true;
            dx = -1; // Mantener movimiento horizontal
        } 
        else if (!agacharse && derecha && arriba) 
        {
            disparoDerechaArriba = true;
            dx = 1; // Mantener movimiento horizontal
        } 
        else if (!agacharse) 
        {
            // Movimiento normal (solo si no se está agachando)
            if (izquierda) {
                dx = -1;
            } 
            else if (derecha) {
                dx = 1;
            }
            // Salto normal (solo cuando se presiona SPACE sin combinaciones)
            if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
            	controladorDeAudio.reproducirSonido("salto");
                saltar = true;
            }
        }

        // Actualizar jugador
//        jugador.actualizar(dx, saltar, disparoIzquierdaArriba, disparoDerechaArriba, agacharse, Gdx.graphics.getDeltaTime());
        jugador.actualizarMovimientoJugador(dx, saltar, disparoIzquierdaArriba, disparoDerechaArriba, agacharse, Gdx.graphics.getDeltaTime(), capaColisiones);
    	
    	
        
        //Camara:
//        camara.position.set(jugador.getX() + jugador.getAncho() / 2f, jugador.getY() + jugador.getAlto() / 2f, 0);
        
        float mapWidth = capaColisiones.getWidth() * capaColisiones.getTileWidth();
        float mapHeight = capaColisiones.getHeight() * capaColisiones.getTileHeight();
        float halfWidth = camara.viewportWidth / 2f;
        float halfHeight = camara.viewportHeight / 2f;

//        float camX = Math.max(halfWidth, Math.min(jugador.getX(), mapWidth - halfWidth));
//        float camY = Math.max(halfHeight, Math.min(jugador.getY(), mapHeight - halfHeight));
        float camX = Math.max(halfWidth, Math.min(jugador.getX() + jugador.getAncho() / 2f, mapWidth - halfWidth));
        float camY = Math.max(halfHeight, Math.min(jugador.getY() + jugador.getAlto() / 2f, mapHeight - halfHeight));

        camara.position.lerp(new Vector3(camX, camY, 0), 0.1f);
        camara.update();
      
        batch.setProjectionMatrix(camara.combined);
        shapeRenderer.setProjectionMatrix(camara.combined);
        
        
        //Mapa: 
        tiledMapRenderer.setView(camara);
        tiledMapRenderer.render();
        
       
        batch.begin();
        jugador.render(batch);
        batch.end();
        
        shapeRenderer.begin(ShapeRenderer.ShapeType.Line);
        shapeRenderer.setColor(Color.RED);
        //La linea de abajo define las dimensiones de la hitbox del jugador:
        shapeRenderer.rect(jugador.getX(), jugador.getY(), jugador.getAncho(), jugador.getAlto());
        shapeRenderer.end();
    }

    public void dispose() {
        batch.dispose();
        image.dispose();
        controladorDeAudio.dispose();
        jugador.dispose();
        shapeRenderer.dispose();
    }
    
    @Override
    public void resize(int width, int height) {
        viewport.update(width, height);
    }


}
