<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="bloque de aparicion" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <image source="bloque de aparicion.png" width="32" height="32"/>
 <wangsets>
  <wangset name="bloque de aparicion" type="mixed" tile="0">
   <wangcolor name="" color="#ff0000" tile="0" probability="1"/>
   <wangtile tileid="0" wangid="1,1,1,1,1,1,1,1"/>
  </wangset>
 </wangsets>
</tileset>
