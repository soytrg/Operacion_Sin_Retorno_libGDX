package hud;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

public class HUD {

    private Stage stage;
    private Viewport viewport;

    private Integer vidas;
    private Integer puntuacion;

    private Label vidasLabel;
    private Label puntuacionLabel;
    private Label tiempoLabel;

    public HUD(SpriteBatch batch) {
        vidas = 3;
        puntuacion = 0;

        // Cámara y viewport independientes del juego
        viewport = new FitViewport(800, 600, new OrthographicCamera());
        stage = new Stage(viewport, batch);

        // Fuente simple para los labels
        BitmapFont font = new BitmapFont();

        // Estilo para Labels
        Label.LabelStyle estilo = new Label.LabelStyle(font, com.badlogic.gdx.graphics.Color.WHITE);

        // Inicializamos los Labels
        vidasLabel = new Label("Vidas: " + vidas, estilo);
        puntuacionLabel = new Label("Puntos: " + puntuacion, estilo);
        tiempoLabel = new Label("Tiempo: 00", estilo);

        // Creamos una tabla para ordenar los elementos
        Table tabla = new Table();
        tabla.top().left();
        tabla.setFillParent(true);

        // Añadimos a la tabla
        tabla.add(vidasLabel).padTop(10).padLeft(10);
        tabla.row();
        tabla.add(puntuacionLabel).padTop(10).padLeft(10);
        tabla.row();
        tabla.add(tiempoLabel).padTop(10).padLeft(10);

        // Añadimos la tabla al Stage
        stage.addActor(tabla);
    }

    public void render() {
        stage.draw();
    }

    public void resize(int width, int height) {
        viewport.update(width, height);
    }

    public void dispose() {
        stage.dispose();
    }

    public void sumarPuntos(int puntos) {
        puntuacion += puntos;
        puntuacionLabel.setText("Puntos: " + puntuacion);
    }

    public void perderVida() {
        if (vidas > 0) vidas--;
        vidasLabel.setText("Vidas: " + vidas);
    }

    public void actualizarTiempo(int segundos) {
        tiempoLabel.setText("Tiempo: " + segundos);
    }

    public Stage getStage() {
        return stage;
    }
}
