package com.MiEmpresa.OperacionSinRetorno;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Jugador {
    private float x, y;
    private float velocidadHorizontal = 200;
    private float velocidadVertical = 0;
    private float velocidadSalto = 400;
    private float gravedad = -800;
    private float suelo = 100; // Altura del suelo
    private boolean enSuelo = true;

    private Texture caminando;
    private Texture quieto;
    private Texture saltando;
    private Texture disparoIzquierdaArriba;
    private Texture disparoDerechaArriba;
    private Texture agachado;
    private Texture imagenActual;

    public Jugador() {
        x = 100;
        y = suelo;

        caminando = new Texture("player_walk.png");
        quieto = new Texture("player.png");
        saltando = new Texture("player_up.png");

        // Nuevas texturas para disparos diagonales
        try {
            disparoIzquierdaArriba = new Texture("player_shoot_left_up.png");
        } catch (Exception e) {
            disparoIzquierdaArriba = new Texture("player_walk.png"); // Temporal
        }

        try {
            disparoDerechaArriba = new Texture("player_shoot_right_up.png");
        } catch (Exception e) {
            disparoDerechaArriba = new Texture("player_walk.png"); // Temporal
        }

        // Nueva textura para agacharse
        try {
            agachado = new Texture("player_down.png");
        } catch (Exception e) {
            agachado = new Texture("player.png"); // Temporal
        }

        imagenActual = quieto;
    }

    public void actualizar(float dx, boolean saltar, boolean disparoIzqArriba, boolean disparoDerrArriba, boolean agacharse, float delta) {
        // Movimiento horizontal (puede moverse mientras está agachado)
        x += dx * velocidadHorizontal * delta;

        // Sistema de salto (solo si no está disparando en diagonal y no está agachado)
        if (saltar && enSuelo && !disparoIzqArriba && !disparoDerrArriba && !agacharse) {
            velocidadVertical = velocidadSalto;
            enSuelo = false;
        }

        // Aplicar gravedad
        velocidadVertical += gravedad * delta;
        y += velocidadVertical * delta;

        // Verificar si toca el suelo
        if (y <= suelo) {
            y = suelo;
            velocidadVertical = 0;
            enSuelo = true;
        }

        // Actualizar imagen según el estado (PRIORIDAD: agacharse > disparos diagonales > salto > caminar > quieto)
        if (agacharse && enSuelo) {
            imagenActual = agachado;
        } else if (disparoIzqArriba) {
            imagenActual = disparoIzquierdaArriba;
        } else if (disparoDerrArriba) {
            imagenActual = disparoDerechaArriba;
        } else if (!enSuelo) {
            imagenActual = saltando;
        } else if (dx != 0) {
            imagenActual = caminando;
        } else {
            imagenActual = quieto;
        }
    }

    public void render(SpriteBatch batch) {
        batch.draw(imagenActual, x, y, 128, 128);
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public void dispose() {
        caminando.dispose();
        quieto.dispose();
        saltando.dispose();
        disparoIzquierdaArriba.dispose();
        disparoDerechaArriba.dispose();
        agachado.dispose();
    }
}