package com.MiEmpresa.OperacionSinRetorno;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.graphics.Color;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Principal extends ApplicationAdapter {

    private SpriteBatch batch;
    private Jugador jugador;
    private ControladorEntrada controlador;
    private ShapeRenderer shapeRenderer;

    @Override
    public void create() {
        batch = new SpriteBatch();
        jugador = new Jugador();
        controlador = new ControladorEntrada();
        shapeRenderer = new ShapeRenderer();

        Gdx.input.setInputProcessor(controlador);
    }

    @Override
    public void render() {
        float dx = 0;
        boolean saltar = false;
        boolean disparoIzquierdaArriba = false;
        boolean disparoDerechaArriba = false;
        boolean agacharse = false;

        // Detectar movimiento horizontal
        boolean izquierda = Gdx.input.isKeyPressed(Input.Keys.A);
        boolean derecha = Gdx.input.isKeyPressed(Input.Keys.D);
        boolean arriba = Gdx.input.isKeyPressed(Input.Keys.W);
        boolean abajo = Gdx.input.isKeyPressed(Input.Keys.S);

        // Detectar agacharse
        if (abajo) {
            agacharse = true;
        }

        // Detectar combinaciones para disparos diagonales (solo si no se está agachando)
        if (!agacharse && izquierda && arriba) {
            disparoIzquierdaArriba = true;
            dx = -1; // Mantener movimiento horizontal
        } else if (!agacharse && derecha && arriba) {
            disparoDerechaArriba = true;
            dx = 1; // Mantener movimiento horizontal
        } else if (!agacharse) {
            // Movimiento normal (solo si no se está agachando)
            if (izquierda) {
                dx = -1;
            } else if (derecha) {
                dx = 1;
            }

            // Salto normal (solo cuando se presiona SPACE sin combinaciones)
            if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
                saltar = true;
            }
        }

        // Actualizar jugador
        jugador.actualizar(dx, saltar, disparoIzquierdaArriba, disparoDerechaArriba, agacharse, Gdx.graphics.getDeltaTime());

        ScreenUtils.clear(0.15f, 0.15f, 0.2f, 1f);
        batch.begin();
        jugador.render(batch);
        batch.end();

        shapeRenderer.begin(ShapeRenderer.ShapeType.Line);
        shapeRenderer.setColor(Color.RED);
        shapeRenderer.rect(jugador.getX(), jugador.getY(), 32, 32);
        shapeRenderer.end();
    }

    @Override
    public void dispose() {
        batch.dispose();
        jugador.dispose();
        shapeRenderer.dispose();
    }
}