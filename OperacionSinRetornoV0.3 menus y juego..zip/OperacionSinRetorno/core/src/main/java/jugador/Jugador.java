package jugador;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;

public class Jugador {
    private float x, y;
    private float velocidadHorizontal = 200;
    private float velocidadVertical = 0;
    private float velocidadSalto = 400;
    private float gravedad = -800;
    private final float ALTO = 32f, ANCHO = 128f;
    private boolean enSuelo = true;

    private Texture caminando;
    private Texture quieto;
    private Texture saltando;
    private Texture disparoIzquierdaArriba;
    private Texture disparoDerechaArriba;
    private Texture agachado;
    private Texture imagenActual;
    
    public Jugador(float startX, float startY) {
    	this.x = startX;
        this.y = startY;

        caminando = new Texture("Jugador Imagenes/player_walk.png");
        quieto = new Texture("Jugador Imagenes/player.png");
        saltando = new Texture("Jugador Imagenes/player_up.png");

        // Nuevas texturas para disparos diagonales
        try {
            disparoIzquierdaArriba = new Texture("Jugador Imagenes/player_shoot_left_up.png");
        } catch (Exception e) {
            disparoIzquierdaArriba = new Texture("Jugador Imagenes/player_walk.png"); // Temporal
        }

        try {
            disparoDerechaArriba = new Texture("Jugador Imagenes/player_shoot_right_up.png");
        } catch (Exception e) {
            disparoDerechaArriba = new Texture("Jugador Imagenes/player_walk.png"); // Temporal
        }

        // Nueva textura para agacharse
        try {
            agachado = new Texture("Jugador Imagenes/player_down.png");
        } catch (Exception e) {
            agachado = new Texture("Jugador Imagenes/player.png"); // Temporal
        }

        imagenActual = quieto;
    }
    
    public float getAlto()
    {
    	return this.ALTO;
    }
    
    public float getAncho()
    {
    	return this.ANCHO;
    }
    
    private boolean hayColisionIzquierda(TiledMapTileLayer capa) {
        float tileWidth = capa.getTileWidth();
        float tileHeight = capa.getTileHeight();

        int xTile = (int)((x - 1) /	 tileWidth);
        int yTileInicio = (int)(y / tileHeight + 1);
        int yTileFin = (int)((y + ALTO - 1) / tileHeight);

        for (int i = yTileInicio; i <= yTileFin; i++) {
            if (capa.getCell(xTile, i) != null) {
                return true;
            }
        }
        return false;
    }

    private boolean hayColisionDerecha(TiledMapTileLayer capa) {
        float tileWidth = capa.getTileWidth();
        float tileHeight = capa.getTileHeight();

        int xTile = (int)((x + ANCHO) / tileWidth);
        int yTileInicio = (int)(y / tileHeight + 1);
        int yTileFin = (int)((y + ALTO - 1) / tileHeight);

        for (int i = yTileInicio; i <= yTileFin; i++) {
            if (capa.getCell(xTile, i) != null) {
                return true;
            }
        }
        return false;
    }
    
    public boolean hayColisionAbajo(TiledMapTileLayer capa) {
        float tileWidth = capa.getTileWidth();
        float tileHeight = capa.getTileHeight();

        int xTileInicio = (int)(x / tileWidth);
        int xTileFin = (int)((x + ANCHO) / tileWidth);
        int yTile = (int)((y - 1) / tileHeight);

        for (int i = xTileInicio; i <= xTileFin; i++) {
            if (capa.getCell(i, yTile) != null) {
                return true; // hay colisión con cualquier tile debajo
            }
        }

        return false;
    }

    public void actualizarMovimientoJugador(float dx, boolean saltar, boolean disparoIzqArriba, boolean disparoDerrArriba, boolean agacharse, float delta, TiledMapTileLayer capa) {
        // Movimiento horizontal (puede moverse mientras está agachado)
//        x += dx * velocidadHorizontal * delta;

        // Sistema de salto (solo si no está disparando en diagonal y no está agachado)
//      if (saltar && enSuelo && !disparoIzqArriba && !disparoDerrArriba && !agacharse) {
        if (saltar && enSuelo) {
            velocidadVertical = velocidadSalto;
            enSuelo = false;
        }

        // Aplicar gravedad
        velocidadVertical += gravedad * delta;
        y += velocidadVertical * delta;

//        // Verificar si toca el suelo
//        if (y <= suelo) {
//            y = suelo;
//            velocidadVertical = 0;
//            enSuelo = true;
//        }
        
        if (dx < 0) { // Mover izquierda
            if (!hayColisionIzquierda(capa)) {
                x += dx * velocidadHorizontal * delta;
            } else {
                int xTile = (int)((x - 1) / capa.getTileWidth());
                x = (xTile + 1) * capa.getTileWidth();
            }
        } else if (dx > 0) { // Mover derecha
            if (!hayColisionDerecha(capa)) {
                x += dx * velocidadHorizontal * delta;
            } else {
                int xTile = (int)((x + ANCHO) / capa.getTileWidth());
                x = xTile * capa.getTileWidth() - ANCHO;
            }
        }
        
        if (hayColisionAbajo(capa)) {
            int yTile = (int)((y - 1) / capa.getTileHeight());
            y = (yTile + 1) * capa.getTileHeight(); // ajusta justo sobre el bloque
            velocidadVertical = 0;
            enSuelo = true;
        } else {
            enSuelo = false;
        }



        // Actualizar imagen según el estado (PRIORIDAD: agacharse > disparos diagonales > salto > caminar > quieto)
        if (agacharse && enSuelo) {
            imagenActual = agachado;
        } 
        
        else if (disparoIzqArriba) {
            imagenActual = disparoIzquierdaArriba;
        } 
        
        else if (disparoDerrArriba) {
            imagenActual = disparoDerechaArriba;
        } 
        
        else if (!enSuelo) {
            imagenActual = saltando;
        } 
        
        else if (dx != 0) {
            imagenActual = caminando;
        } 
        
        else {
            imagenActual = quieto;
        }
    }

    public void render(SpriteBatch batch) {
        batch.draw(imagenActual, x, y, this.ANCHO, this.ALTO);
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public void dispose() {
        caminando.dispose();
        quieto.dispose();
        saltando.dispose();
        disparoIzquierdaArriba.dispose();
        disparoDerechaArriba.dispose();
        agachado.dispose();
    }
}